"use strict";

/* ============================================================
   typeflow — typing engine
   modes: time / words / daily
   ============================================================ */

const $ = (s) => document.querySelector(s);

/* ---------- word data ---------- */
const WORDS = (
  "the be of and a to in he have it that for they i with as not on she at by this we you do but from or which one would all will there say who make when can more if no man out other so what time up go about than into could state only new year some take come these know see use get like then first any work now may such give over think most even find day also after way many must look before great back through long where much should well people down own just because good each those feel seem how high too place little world very still nation hand old life tell write become here show house both between need mean call develop under last right move thing general school never same another begin while number part turn real leave might want point form off child few small since against ask late home interest large person end open public follow during present without again hold govern around possible head consider word program problem however lead system set order eye plan run keep face fact group play stand increase early course change help line river boat sea fire land animal mother father home song run walk throw hear music teacher water paper story women road city power"
).split(/\s+/);

/* ---------- elements ---------- */
const el = {
  modes: $("#modes"),
  subbar: $("#subbar"),
  optPunct: $("#opt-punct"),
  optNums: $("#opt-nums"),
  liveWpm: $("#live-wpm"),
  liveAcc: $("#live-acc"),
  liveTime: $("#live-time"),
  livePb: $("#live-pb"),
  timeLabel: $("#time-label"),
  weakstrip: $("#weakstrip"),
  typewrap: $("#typewrap"),
  words: $("#words"),
  caret: $("#caret"),
  focusnote: $("#focusnote"),
  livegraph: $("#livegraph"),
  input: $("#mobile-input"),
  testView: $("#test-view"),
  resultsView: $("#results-view"),
  resWpm: $("#res-wpm"),
  resAcc: $("#res-acc"),
  resCons: $("#res-cons"),
  resRaw: $("#res-raw"),
  resTime: $("#res-time"),
  resChars: $("#res-chars"),
  resGraph: $("#resgraph"),
  resultMeta: $("#result-meta"),
  pbBadge: $("#pb-badge"),
  weakPanel: $("#weak-panel"),
  heatmap: $("#heatmap"),
  practiceBtn: $("#practice-btn"),
  nextBtn: $("#next-btn"),
  repeatBtn: $("#repeat-btn"),
  rpPlay: $("#rp-play"),
  rpSpeed: $("#rp-speed"),
  rpTrack: $("#rp-track"),
  rpFill: $("#rp-fill"),
  rpWpm: $("#rp-wpm"),
  replayText: $("#replay-text"),
  modeNote: $("#modenote"),
  liveLeft: $("#live-left"),
  statLeft: $("#stat-left"),
  resKpm: $("#res-kpm"),
  resUncorr: $("#res-uncorr"),
  optCaps: $("#opt-caps"),
  optSound: $("#opt-sound"),
  optLofi: $("#opt-lofi"),
  lofiPop: $("#lofi-pop"),
  lofiMount: $("#lofi-mount"),
  lofiClose: $("#lofi-close"),
  lofiMin: $("#lofi-min"),
  lofiNote: $("#lofi-note"),
  optTheme: $("#opt-theme"),
  optZen: $("#opt-zen"),
  soundVolume: $("#sound-volume"),
  volumeValue: $("#volume-value"),
  zenExit: $("#zen-exit"),
  btnStats: $("#btn-stats"),
  btnSettings: $("#btn-settings"),
  settingsPop: $("#settings-pop"),
  logo: $("#logo"),
  dailyResult: $("#daily-result"),
  dailyStreak: $("#daily-streak"),
  shareBtn: $("#share-btn"),
  statsView: $("#stats-view"),
  statsClose: $("#stats-close"),
  statsTotals: $("#stats-totals"),
  histGraph: $("#histgraph"),
  pbTable: $("#pbtable"),
  clearHistory: $("#clear-history"),
  cmdOverlay: $("#cmd-overlay"),
  cmdInput: $("#cmd-input"),
  cmdList: $("#cmd-list"),
  endBtn: $("#end-btn")
};

/* ---------- state ---------- */
const S = {
  mode: "time",
  limit: 30,
  punct: false,
  nums: false,
  caps: false,
  words: [],
  input: [],
  wordEls: [],
  boundaryOk: [],
  wi: 0,
  LH: 58,
  started: false,
  finished: false,
  startTime: 0,
  timer: null,
  keystrokes: 0,
  correctKeystrokes: 0,
  correctInText: 0,
  typedChars: 0,
  keys: {},          // per-key {t: attempts, e: errors}
  samples: [],       // per-second {wpm, raw, err}
  errsThisSec: 0,
  lastSec: 0,
  events: [],        // replay log {t, k:'c'|'b', ch, ok}
  lastConfig: null,
  paused: false,
  pauseAt: 0
};

const ENDLESS = "∞";
const LIMITS = { time: [15, 30, 60, 120, ENDLESS], words: [10, 25, 50, 100, ENDLESS] };
const PB_PREFIX = "typeflow_pb_";
const HIST_KEY = "typeflow_history";
const DAILY_KEY = "typeflow_daily";
const SETTINGS_KEY = "typeflow_settings";
const SOUND_KEY = "typeflow_sound";

/* ---------- storage (safe on file://) ---------- */
function load(key, fallback) {
  try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); }
  catch { return fallback; }
}
function save(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* ignore */ }
}
function pbKey() {
  const limited = LIMITS[S.mode] ? "_" + S.limit : "";
  const flags = (S.mode === "time" || S.mode === "words")
    ? ((S.punct ? "p" : "") + (S.nums ? "n" : "") + (S.caps ? "c" : "")) : "";
  return PB_PREFIX + S.mode + limited + flags;
}
function getPb() { return load(pbKey(), 0); }

/* ---------- daily challenge ---------- */
function dateKey(d) {
  return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
}
function todayKey() { return dateKey(new Date()); }
function yesterdayKey() {
  const d = new Date(); d.setDate(d.getDate() - 1); return dateKey(d);
}
// FNV-1a string hash → 32-bit seed
function seedFromStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
// mulberry32 — tiny deterministic PRNG
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function genDaily() {
  const rng = mulberry32(seedFromStr("typeflow-" + todayKey()));
  const out = [];
  let prev = "";
  for (let i = 0; i < 40; i++) {
    let w;
    do { w = WORDS[Math.floor(rng() * WORDS.length)]; } while (w === prev);
    out.push(w); prev = w;
  }
  return out;
}
function getDailyState() {
  const st = load(DAILY_KEY, { streak: 0, last: "", best: 0, count: 0 });
  // a streak breaks if the last completed day wasn't yesterday or today
  if (st.last !== todayKey() && st.last !== yesterdayKey()) st.streak = 0;
  return st;
}
function recordDaily(wpm) {
  const st = load(DAILY_KEY, { streak: 0, last: "", best: 0, count: 0 });
  if (st.last !== todayKey()) {
    st.streak = (st.last === yesterdayKey()) ? st.streak + 1 : 1;
    st.last = todayKey();
    st.count = (st.count || 0) + 1;
  }
  if (wpm > st.best) st.best = wpm;
  save(DAILY_KEY, st);
  return st;
}

/* ---------- word generation ---------- */
function rand(n) { return Math.floor(Math.random() * n); }
function pick(arr) { return arr[rand(arr.length)]; }

function decorate(word) {
  if (S.nums && Math.random() < 0.15) {
    return String(1 + rand(9999));
  }
  if (S.caps && Math.random() < 0.18) {
    word = word[0].toUpperCase() + word.slice(1);
  }
  if (S.punct) {
    if (Math.random() < 0.12) word = word[0].toUpperCase() + word.slice(1);
    if (Math.random() < 0.22) word += pick([".", ",", "!", "?", '"', "'", "-", ";"]);
  }
  return word;
}

function genWord(previous) {
  // avoid the same word 3x in a row
  let w;
  do { w = pick(WORDS); } while (w === previous);
  return decorate(w);
}

function weakKeyList() {
  return Object.entries(S.keys)
    .filter(([, v]) => v.t >= 6 && v.e / v.t >= 0.3)
    .sort((a, b) => b[1].e / b[1].t - a[1].e / a[1].t)
    .map(([k]) => k);
}

function genWords(count) {
  const out = [];
  let prev = "";
  for (let i = 0; i < count; i++) {
    // adaptive: inject words with weak letters periodically
    if (i > 0 && i % 12 === 0) {
      const wk = weakKeyList();
      if (wk.length) {
        const key = pick(wk);
        const pool = WORDS.filter((w) => w.includes(key));
        if (pool.length) { out.push(decorate(pick(pool))); prev = out[out.length - 1]; continue; }
      }
    }
    const w = genWord(prev);
    out.push(w);
    prev = w;
  }
  return out;
}

function genPractice() {
  const wk = weakKeyList();
  const out = [];
  if (wk.length) {
    for (let i = 0; i < 30; i++) {
      const key = pick(wk);
      const pool = WORDS.filter((w) => w.includes(key));
      out.push(pool.length ? pick(pool) : pick(WORDS));
    }
  } else {
    for (let i = 0; i < 30; i++) out.push(pick(WORDS));
  }
  return out;
}

/* ---------- rendering ---------- */
function buildWordEl(word) {
  const d = document.createElement("div");
  d.className = "word";
  for (const ch of word) {
    const s = document.createElement("span");
    s.className = "letter";
    s.textContent = ch;
    d.appendChild(s);
  }
  return d;
}

function renderAll() {
  el.words.innerHTML = "";
  S.wordEls = [];
  const frag = document.createDocumentFragment();
  for (const w of S.words) {
    const d = buildWordEl(w);
    frag.appendChild(d);
    S.wordEls.push(d);
  }
  el.words.appendChild(frag);
  el.words.style.transform = "translateY(0)";
  // position synchronously (rAF can be throttled in background/hidden contexts),
  // then re-sync once more after layout settles (e.g. webfont swap)
  updateScroll();
  setCaret();
  requestAnimationFrame(() => {
    S.LH = S.wordEls[0] ? S.wordEls[0].getBoundingClientRect().height : 58;
    updateScroll();
    setCaret();
  });
}

function setCaret() {
  const w = S.wordEls[S.wi];
  if (!w) return;
  const ci = S.input[S.wi].length;
  const spans = w.children;
  const wrapRect = el.typewrap.getBoundingClientRect();
  let x, y, h;
  if (ci < spans.length) {
    const r = spans[ci].getBoundingClientRect();
    x = r.left - wrapRect.left;
    y = r.top - wrapRect.top;
    h = r.height;
  } else if (spans.length) {
    const r = spans[spans.length - 1].getBoundingClientRect();
    x = r.right - wrapRect.left;
    y = r.top - wrapRect.top;
    h = r.height;
  } else {
    const r = w.getBoundingClientRect();
    x = r.left - wrapRect.left;
    y = r.top - wrapRect.top;
    h = r.height;
  }
  el.caret.style.height = h + "px";
  el.caret.style.transform = `translate(${x}px, ${y}px)`;
}

function updateScroll() {
  const w = S.wordEls[S.wi];
  if (!w) return;
  const target = Math.max(0, w.offsetTop - S.LH);
  el.words.style.transform = `translateY(${-target}px)`;
}

/* ---------- live stats ---------- */
function elapsedSec() {
  if (!S.started) return 0;
  return (performance.now() - S.startTime) / 1000;
}

function isEndless() { return S.limit === ENDLESS; }
function trunc1(v) { return (Math.floor(v * 10) / 10).toFixed(1); }

/* ---------- live values ---------- */
/* WPM is the real cumulative figure: correct characters / 5 / minutes typed.
   The 1.5s floor only tames the impossible opening spike before any time has
   passed; after that it's the true number, shown as a whole figure. */
function liveWpmValue() {
  const secs = elapsedSec();
  if (secs < 0.4) return 0;
  return (S.correctInText / 5) / (secs / 60);
}

function updateLive() {
  el.liveWpm.textContent = Math.round(liveWpmValue());
  el.liveAcc.textContent =
    S.keystrokes === 0 ? "100%" : Math.round((S.correctKeystrokes / S.keystrokes) * 100) + "%";
}

function updateWeakStrip() {
  const wk = weakKeyList().slice(0, 2);
  el.weakstrip.innerHTML = "";
  for (const k of wk) {
    const v = S.keys[k];
    const chip = document.createElement("span");
    chip.className = "weakchip";
    chip.textContent = `${k} ${Math.round((v.e / v.t) * 100)}%`;
    el.weakstrip.appendChild(chip);
  }
}

/* ---------- canvas helpers ---------- */
function fitCanvas(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return { ctx, w, h };
}

function themeAccent() {
  return getComputedStyle(document.body).getPropertyValue("--accent").trim() || "#7aa2ff";
}

function themeAccentRgba(alpha) {
  const rgb = getComputedStyle(document.body).getPropertyValue("--accent-rgb").trim() || "122, 162, 255";
  return `rgba(${rgb},${alpha})`;
}

function drawSeries(ctx, pts, w, h, maxV, pad) {
  if (pts.length < 2) return;
  const step = w / Math.max(pts.length - 1, 1);
  ctx.beginPath();
  pts.forEach((v, i) => {
    const x = i * step;
    const y = h - pad - (v / maxV) * (h - pad * 2);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
}

function drawLive() {
  const graph = el.livegraph;
  if (S.samples.length < 2) { graph.hidden = true; return; }
  graph.hidden = false;
  const { ctx, w, h } = fitCanvas(graph);
  const maxV = Math.max(60, ...S.samples.map((s) => Math.max(s.wpm, s.raw))) * 1.15;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  drawSeries(ctx, S.samples.map((s) => s.raw), w, h, maxV, 10);
  ctx.strokeStyle = themeAccentRgba(0.25);
  ctx.lineWidth = 2;
  ctx.stroke();
  drawSeries(ctx, S.samples.map((s) => s.wpm), w, h, maxV, 10);
  ctx.strokeStyle = themeAccent();
  ctx.lineWidth = 2.5;
  ctx.stroke();
}

function drawResults() {
  // un-hide before measuring: fitCanvas reads clientHeight, which is 0 while
  // the canvas is hidden — a graph hidden by an earlier test would draw blank
  el.resGraph.style.display = "";
  const { ctx, w, h } = fitCanvas(el.resGraph);
  const samples = S.samples;
  if (samples.length < 2) { el.resGraph.style.display = "none"; return; }
  const maxV = Math.max(60, ...samples.map((s) => Math.max(s.wpm, s.raw))) * 1.15;
  const pad = 16;
  const step = w / Math.max(samples.length - 1, 1);
  const yOf = (v) => h - pad - (v / maxV) * (h - pad * 2);

  // grid
  ctx.strokeStyle = "rgba(255,255,255,0.04)";
  ctx.lineWidth = 1;
  for (let i = 1; i <= 3; i++) {
    const y = (h / 4) * i;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }

  // fill under wpm
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, themeAccentRgba(0.18));
  grad.addColorStop(1, themeAccentRgba(0));
  drawSeries(ctx, samples.map((s) => s.wpm), w, h, maxV, pad);
  ctx.lineTo((samples.length - 1) * step, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // raw line
  drawSeries(ctx, samples.map((s) => s.raw), w, h, maxV, pad);
  ctx.strokeStyle = "rgba(255,255,255,0.18)";
  ctx.lineWidth = 2;
  ctx.stroke();

  // wpm line
  drawSeries(ctx, samples.map((s) => s.wpm), w, h, maxV, pad);
  ctx.strokeStyle = themeAccent();
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // error dots
  ctx.fillStyle = "#ff6b81";
  samples.forEach((s, i) => {
    if (s.err > 0) {
      ctx.beginPath();
      ctx.arc(i * step, yOf(s.wpm), Math.min(2 + s.err, 6), 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

/* ---------- typing sounds: real mechanical-keyboard recordings ---------- */
const SAMPLE_PROFILES = ["cream", "boxnavy", "topre", "alpaca", "turquoise", "off"];
const SAMPLE_CONFIG = {};
let soundOn = load(SOUND_KEY, false);
let soundProfile = load(SOUND_KEY + "_profile", "cream");
let soundVolume = load(SOUND_KEY + "_volume", 0.65);

const sampleCache = new Map();
function samplePath(profile, kind, variation = 0) {
  const config = SAMPLE_CONFIG[profile] || { extension: "mp3", variations: 5 };
  const file = kind === "space" || kind === "backspace" ? kind : `key-${variation}`;
  return `/sounds/${profile}/${file}.${config.extension}`;
}
function getSample(path) {
  const pool = sampleCache.get(path) || [];
  let audio = pool.find((item) => item.paused || item.ended);
  if (!audio) {
    audio = new Audio(path);
    audio.preload = "auto";
    pool.push(audio);
    sampleCache.set(path, pool);
  }
  return audio;
}
function preloadSamples(profile) {
  if (profile === "off") return;
  const variations = (SAMPLE_CONFIG[profile] || { variations: 5 }).variations;
  for (let i = 0; i < variations; i++) getSample(samplePath(profile, "key", i));
  getSample(samplePath(profile, "space"));
  getSample(samplePath(profile, "backspace"));
}
function playKeySound(ok, isSpace, isBackspace) {
  if (!soundOn || soundProfile === "off") return;
  const kind = isSpace ? "space" : isBackspace ? "backspace" : "key";
  const variations = (SAMPLE_CONFIG[soundProfile] || { variations: 5 }).variations;
  const path = samplePath(soundProfile, kind, Math.floor(Math.random() * variations));
  const audio = getSample(path);
  audio.currentTime = 0;
  audio.volume = Math.min(1, soundVolume * (ok ? 1 : 0.88));
  audio.playbackRate = 0.97 + Math.random() * 0.06;
  audio.play().catch(() => {});
}
function setProfile(name) {
  if (!SAMPLE_PROFILES.includes(name)) name = "cream";
  soundProfile = name;
  save(SOUND_KEY + "_profile", name);
  const box = $("#sound-profiles");
  if (box) for (const b of box.children) b.classList.toggle("active", b.dataset.p === name);
  preloadSamples(name);
}
function setSound(on) {
  if (on && soundProfile === "off") setProfile("cream");
  soundOn = on;
  save(SOUND_KEY, on);
  el.optSound.classList.toggle("active", on);
  if (on) preloadSamples(soundProfile);
}
function setVolume(value) {
  soundVolume = Math.max(0, Math.min(1, value));
  save(SOUND_KEY + "_volume", soundVolume);
  el.soundVolume.value = Math.round(soundVolume * 100);
  el.volumeValue.textContent = Math.round(soundVolume * 100) + "%";
}

let previewTimers = [];
function playPreviewHit(profile, kind = "key") {
  const variations = (SAMPLE_CONFIG[profile] || { variations: 5 }).variations;
  const path = samplePath(profile, kind, Math.floor(Math.random() * variations));
  const audio = getSample(path);
  audio.currentTime = 0;
  audio.volume = Math.min(1, Math.max(0.12, soundVolume));
  audio.playbackRate = 0.97 + Math.random() * 0.06;
  audio.play().catch(() => {});
}

function previewProfile(profile) {
  for (const timer of previewTimers) clearTimeout(timer);
  previewTimers = [];
  if (profile === "off") return;
  // Start synchronously so browsers treat the preview as part of the click.
  playPreviewHit(profile);
  const rhythm = [0, 82, 148, 245, 316, 392, 505];
  rhythm.slice(1).forEach((delay, index) => {
    const timer = setTimeout(() => {
      playPreviewHit(profile, index === rhythm.length - 2 ? "space" : "key");
    }, delay);
    previewTimers.push(timer);
  });
}

function unlockSoundPreviews() {
  const profile = soundProfile === "off" ? "cream" : soundProfile;
  const audio = new Audio(samplePath(profile, "key", 0));
  audio.preload = "auto";
  audio.volume = 0;
  audio.play()
    .then(() => {
      audio.pause();
      audio.currentTime = 0;
      audio.volume = soundVolume;
    })
    .catch(() => {});
}

/* ---------- lofi girl live stream (mini player) ---------- */
const LOFI_STREAM_ID = "rFZHOHl-L8A"; // Lofi Girl — "lofi hip hop radio 📚 beats to relax/study to" (live, embeddable)
const LOFI_WATCH_URL = "https://www.youtube.com/watch?v=" + LOFI_STREAM_ID;
let lofiApiPromise = null;
let lofiPlayer = null;
let lofiWanted = false;
// last minimize state, remembered across restarts of the stream and page reloads
let lofiMinimized = load("typeflow_lofi_min", false);

function lofiApiReady() {
  if (window.YT && window.YT.Player) return Promise.resolve();
  if (!lofiApiPromise) {
    lofiApiPromise = new Promise((resolve) => {
      const previous = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (typeof previous === "function") previous();
        resolve();
      };
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      document.head.appendChild(tag);
    });
  }
  return lofiApiPromise;
}

function renderLofiState() {
  el.optLofi.classList.toggle("active", lofiWanted);
  el.lofiPop.classList.toggle("open", lofiWanted);
  el.lofiPop.classList.toggle("min", lofiMinimized);
  el.lofiMin.textContent = lofiMinimized ? "▲" : "─";
  el.lofiMin.title = lofiMinimized ? "expand" : "minimize";
}

function startLofi() {
  lofiWanted = true;
  el.lofiNote.hidden = true;
  renderLofiState(); // opens in whatever state was last used (saved preference)

  const apiReady = Promise.race([
    lofiApiReady(),
    new Promise((_, reject) => setTimeout(() => reject(new Error("youtube api timeout")), 10000))
  ]);

  apiReady.then(() => {
    if (!lofiWanted) return; // toggled back off while the API was loading
    if (lofiPlayer) { lofiPlayer.playVideo(); return; }
    lofiPlayer = new window.YT.Player(el.lofiMount, {
      videoId: LOFI_STREAM_ID,
      playerVars: {
        autoplay: 1,
        controls: 1,
        playsinline: 1,
        rel: 0,
        modestbranding: 1,
        iv_load_policy: 3,
        disablekb: 1
      },
      events: {
        onReady: (e) => { if (lofiWanted) e.target.playVideo(); },
        onStateChange: (e) => {
          if (e.data === window.YT.PlayerState.PLAYING) el.lofiNote.hidden = true;
        },
        onError: (e) => {
          el.lofiNote.textContent = "open on youtube ↗";
          el.lofiNote.title = "youtube error " + e.data; // 101/150 = embedding blocked, 153 = player config
          el.lofiNote.hidden = false;
        }
      }
    });
  }, () => {
    el.lofiNote.textContent = "couldn't load";
    el.lofiNote.title = "the youtube player api did not load";
    el.lofiNote.hidden = false;
  });
}

function stopLofi() {
  lofiWanted = false;
  // Intentionally keep lofiMinimized: removing .min in the same frame as .open would
  // pop the collapsed pill back open and flash the video during the fade-out.
  // It also doubles as the remembered preference for the next open.
  renderLofiState();
  if (lofiPlayer) lofiPlayer.pauseVideo();
}

el.lofiNote.href = LOFI_WATCH_URL;
lofiApiReady(); // warm up the player API so the first click starts immediately

/* ---------- typing input handling ---------- */
function handleChar(ch) {
  if (S.finished || S.paused) return;
  if (ch === "\n" || ch === "\r") return; // mobile enter

  const w = S.words[S.wi];
  const inp = S.input[S.wi];
  if (ch === " " && inp.length === 0 && !S.started) return; // stray space: don't start
  if (!S.started) startTest();
  if (ch === " ") {
    if (inp.length === 0) return;
    S.keystrokes++;
    S.typedChars++;           // the space is a keystroke/character like any other
    const ok = inp === w;
    if (ok) { S.correctKeystrokes++; S.correctInText++; }
    S.boundaryOk[S.wi] = ok;
    S.events.push({ t: perf(), k: "c", ch: " ", ok });
    if (!ok) S.errsThisSec++;
    playKeySound(ok, true);
    markWordComplete(S.wi, inp, w);
    S.wi++;
    if (S.wi >= S.words.length) { finish(); return; } // space past the last word
    if (S.input[S.wi] === undefined) S.input[S.wi] = "";
    ensureMore();
    updateScroll();
    setCaret();
    updateLive();
    return;
  }

  S.keystrokes++;
  S.typedChars++;
  const expected = inp.length < w.length ? w[inp.length] : null;
  const ok = expected === ch;
  if (expected) {
    const st = (S.keys[expected] = S.keys[expected] || { t: 0, e: 0 });
    st.t++;
    if (!ok) st.e++;
  }
  if (ok) {
    S.correctKeystrokes++;
    S.correctInText++;
  }
  S.events.push({ t: perf(), k: "c", ch, ok });
  if (!ok) S.errsThisSec++;
  playKeySound(ok);

  const wordEl = S.wordEls[S.wi];
  const ci = inp.length;
  if (ci < w.length) {
    wordEl.children[ci].classList.add(ok ? "done" : "bad");
  } else {
    const span = document.createElement("span");
    span.className = "letter extra";
    span.textContent = ch;
    wordEl.appendChild(span);
  }
  S.input[S.wi] = inp + ch;

  updateWeakStrip();
  setCaret();
  updateLive();

  // finite modes end when the last char of the last word is typed
  if (S.mode !== "time" && S.wi === S.words.length - 1 && S.input[S.wi].length >= w.length) {
    finish();
  }
}

function markWordComplete(wi, inp, w) {
  if (inp !== w) {
    const wordEl = S.wordEls[wi];
    wordEl.classList.add("wrong");
    for (let j = inp.length; j < w.length; j++) {
      wordEl.children[j].classList.add("missed");
    }
  }
}

function unmarkWord(wi) {
  const wordEl = S.wordEls[wi];
  wordEl.classList.remove("wrong");
  for (const s of wordEl.children) s.classList.remove("missed");
}

function handleBackspace() {
  if (S.finished || S.paused) return;
  if (S.input[S.wi].length === 0) {
    if (S.wi === 0) return;
    // only step back into a word that had errors
    if (S.input[S.wi - 1] === S.words[S.wi - 1]) return;
    if (S.boundaryOk[S.wi - 1]) S.correctInText--;
    S.wi--;
    unmarkWord(S.wi);
  }
  const w = S.words[S.wi];
  const inp = S.input[S.wi];
  const ci = inp.length - 1;
  const ch = inp[ci];
  if (ci < w.length && w[ci] === ch) S.correctInText--;
  S.events.push({ t: perf(), k: "b" });
  playKeySound(true, false, true);

  const wordEl = S.wordEls[S.wi];
  if (ci >= w.length) {
    wordEl.lastChild.remove();
  } else {
    wordEl.children[ci].classList.remove("done", "bad");
  }
  unmarkWord(S.wi);
  S.input[S.wi] = inp.slice(0, ci);
  setCaret();
  updateLive();
}

/* ---------- test lifecycle ---------- */
function perf() { return performance.now() - S.startTime; }

function startTest() {
  S.started = true;
  S.startTime = performance.now();
  el.caret.classList.remove("idle");
  S.timer = setInterval(tick, 100);
  el.endBtn.hidden = !isEndless();
}

function pushSample() {
  const mins = Math.max(perf() / 60000, 1 / 6000);
  S.samples.push({
    wpm: S.correctInText / 5 / mins,
    raw: S.typedChars / 5 / mins,
    err: S.errsThisSec
  });
  S.errsThisSec = 0;
  drawLive();
}

function tick() {
  if (S.paused) return;
  const el0 = elapsedSec();
  if (S.mode === "time" && !isEndless()) {
    const rem = Math.max(0, S.limit - el0);
    el.liveTime.textContent = trunc1(rem);
    if (rem <= 0) { finish(); return; }
  } else {
    el.liveTime.textContent = trunc1(el0); // count-up (incl. endless)
  }
  // words remaining (finite modes only)
  if (S.mode !== "time" && !isEndless()) {
    el.liveLeft.textContent = Math.max(0, S.words.length - S.wi);
  }
  const sec = Math.floor(el0);
  while (S.lastSec < sec) { pushSample(); S.lastSec++; }
  updateLive();
}

function ensureMore() {
  // time mode grows forever; words mode only when it's endless
  const wantsMore = S.mode === "time" || (S.mode === "words" && isEndless());
  if (!wantsMore) return;
  if (S.wi > S.words.length - 20) {
    const more = genWords(30);
    for (const w of more) {
      S.words.push(w);
      S.input.push("");
      const d = buildWordEl(w);
      el.words.appendChild(d);
      S.wordEls.push(d);
    }
  }
}

function finish() {
  if (S.finished) return;
  S.finished = true;
  clearInterval(S.timer);
  // final partial second sample
  const sec = Math.floor(elapsedSec());
  while (S.lastSec < sec) { pushSample(); S.lastSec++; }
  el.caret.style.opacity = "0";
  document.activeElement && document.activeElement.blur();
  showResults();
}

function computeResults() {
  const timeSec = (S.mode === "time" && !isEndless()) ? S.limit : Math.max(elapsedSec(), 1);
  const mins = timeSec / 60;

  let correct = 0, incorrect = 0, extra = 0;
  for (let i = 0; i < S.words.length; i++) {
    const w = S.words[i];
    const inp = S.input[i] || "";
    for (let j = 0; j < Math.max(w.length, inp.length); j++) {
      if (j >= inp.length) incorrect++;        // missed letter
      else if (j >= w.length) extra++;          // overflow letter
      else if (w[j] === inp[j]) correct++;
      else incorrect++;
    }
    // the space you typed to leave this word is a character too — counting it
    // keeps the final wpm in step with the live counter and the standard
    // chars/5/minutes formula. S.boundaryOk[i] is only set once that space is
    // actually pressed, so untyped trailing words are skipped.
    if (S.boundaryOk[i] === true) correct++;
    else if (S.boundaryOk[i] === false) incorrect++;
  }

  const wpm = Math.round(correct / 5 / mins);
  const raw = Math.round((correct + incorrect + extra) / 5 / mins);
  const acc = S.keystrokes ? Math.round((S.correctKeystrokes / S.keystrokes) * 100) : 100;
  const kpm = Math.round(S.keystrokes / mins);

  // consistency (kogasa): 100 * (1 - tanh(std/mean)) over per-second raw wpm
  let cons = 100;
  if (S.samples.length >= 2) {
    const vals = S.samples.map((s) => s.raw);
    const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
    if (mean > 0) {
      const std = Math.sqrt(vals.reduce((a, b) => a + (b - mean) ** 2, 0) / vals.length);
      cons = Math.round(100 * (1 - Math.tanh(std / mean)));
    }
  }

  return { wpm, raw, acc, cons, kpm, correct, incorrect, extra, timeSec };
}

function showResults() {
  const r = computeResults();
  window.__lastResult = r; // used by the share button
  el.resWpm.textContent = r.wpm;
  el.resAcc.textContent = r.acc + "%";
  el.resCons.textContent = r.cons + "%";
  el.resRaw.textContent = r.raw;
  el.resKpm.textContent = r.kpm;
  el.resTime.textContent = trunc1(r.timeSec) + "s";
  el.resUncorr.textContent = r.incorrect;
  el.resChars.innerHTML =
    `<span class="c-ok">${r.correct}</span>/<span class="c-bad">${r.incorrect}</span>/<span class="c-extra">${r.extra}</span>`;

  const meta = modeLabel();
  el.resultMeta.textContent = meta;

  // personal best
  const pb = getPb();
  if (r.wpm > pb) {
    save(pbKey(), r.wpm);
    el.pbBadge.hidden = false;
  } else {
    el.pbBadge.hidden = true;
  }
  el.livePb.textContent = getPb() || "—";

  // daily challenge: update streak + show share bar
  if (S.mode === "daily") {
    const st = recordDaily(r.wpm);
    el.dailyResult.hidden = false;
    el.dailyStreak.innerHTML =
      `streak <b>${st.streak}</b> day${st.streak === 1 ? "" : "s"} · best <b>${st.best}</b> wpm`;
  } else {
    el.dailyResult.hidden = true;
  }

  // history log (skip practice runs — they're drills, not real tests)
  if (S.mode !== "practice") {
    const h = load(HIST_KEY, []);
    h.push({ t: Date.now(), wpm: r.wpm, acc: r.acc, cons: r.cons, mode: S.mode, lim: S.limit, sec: r.timeSec });
    if (h.length > 400) h.splice(0, h.length - 400);
    save(HIST_KEY, h);
  }

  el.testView.hidden = true;
  el.resultsView.hidden = false;

  drawResults();
  buildHeatmap();
  buildReplay();
}

/* ---------- weak keys heatmap ---------- */
function buildHeatmap() {
  const rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"];
  el.heatmap.innerHTML = "";
  let any = false;
  for (const row of rows) {
    const rowEl = document.createElement("div");
    rowEl.className = "kb-row";
    for (const k of row) {
      const key = document.createElement("div");
      key.className = "key";
      key.textContent = k;
      const st = S.keys[k];
      if (st && st.t) {
        any = true;
        const rate = st.e / st.t;
        if (rate === 0) {
          key.style.background = "rgba(126,231,135,0.12)";
        } else {
          key.style.background = `rgba(255,107,129,${(0.1 + rate * 0.55).toFixed(2)})`;
          if (rate >= 0.25) key.style.color = "#ff6b81";
        }
        key.title = `${k}: ${st.e}/${st.t} errors`;
      }
      rowEl.appendChild(key);
    }
    el.heatmap.appendChild(rowEl);
  }
  el.weakPanel.hidden = !any;
}

/* ---------- replay ---------- */
const R = {
  active: false,
  playing: false,
  speed: 1,
  elapsed: 0,
  lastFrame: 0,
  ptr: 0,
  wi: 0,
  input: [],
  wordEls: [],
  correct: 0,
  timer: null
};

function buildReplay() {
  R.active = S.events.length > 0;
  R.playing = false;
  R.speed = 1;
  R.elapsed = 0;
  R.ptr = 0;
  R.wi = 0;
  R.input = S.words.map(() => "");
  R.correct = 0;
  el.rpPlay.textContent = "▶";
  el.rpSpeed.textContent = "1x";
  el.rpFill.style.width = "0%";
  el.rpWpm.textContent = "0 wpm";

  el.replayText.innerHTML = "";
  R.wordEls = [];
  const frag = document.createDocumentFragment();
  for (const w of S.words) {
    const d = buildWordEl(w);
    frag.appendChild(d);
    R.wordEls.push(d);
  }
  el.replayText.appendChild(frag);
}

function replayApply(e) {
  if (R.wi >= S.words.length) return;
  if (e.k === "b") {
    if (!R.input[R.wi]) return;
    if (R.input[R.wi].length === 0) {
      if (R.wi === 0) return;
      R.wi--;
    }
    if (!R.input[R.wi] || !R.wordEls[R.wi]) return;
    const ci = R.input[R.wi].length - 1;
    if (ci < 0) return;
    const wordEl = R.wordEls[R.wi];
    if (ci >= S.words[R.wi].length) { if (wordEl.lastChild) wordEl.lastChild.remove(); }
    else wordEl.children[ci].classList.remove("done", "bad");
    R.input[R.wi] = R.input[R.wi].slice(0, ci);
    return;
  }
  // char
  if (e.ch === " ") {
    if (R.input[R.wi].length === 0) return;
    R.wi++;
    if (R.input[R.wi] === undefined) R.input[R.wi] = "";
    return;
  }
  const w = S.words[R.wi];
  const inp = R.input[R.wi];
  if (inp === undefined || !w || !R.wordEls[R.wi]) return;
  const ci = inp.length;
  if (e.ok) R.correct++;
  if (ci < w.length) {
    const target = R.wordEls[R.wi].children[ci];
    if (target) target.classList.add(e.ok ? "done" : "bad");
  } else {
    const span = document.createElement("span");
    span.className = "letter extra";
    span.textContent = e.ch;
    R.wordEls[R.wi].appendChild(span);
  }
  R.input[R.wi] = inp + e.ch;
}

function replaySeek(ms) {
  // reset and reapply from start (cheap: events are small)
  R.wi = 0;
  R.input = S.words.map(() => "");
  R.correct = 0;
  R.ptr = 0;
  for (let i = 0; i < S.words.length; i++) {
    const d = R.wordEls[i];
    if (!d) break;
    // rebuild extras removal
    const target = S.words[i];
    while (d.children.length > target.length) d.lastChild.remove();
    for (const s of d.children) s.classList.remove("done", "bad");
  }
  while (R.ptr < S.events.length && S.events[R.ptr].t <= ms) {
    replayApply(S.events[R.ptr]);
    R.ptr++;
  }
  R.elapsed = ms;
  updateReplayHud();
}

function updateReplayHud() {
  const total = replayTotal();
  el.rpFill.style.width = Math.min(100, (R.elapsed / total) * 100) + "%";
  const mins = Math.max(R.elapsed / 60000, 1 / 6000);
  el.rpWpm.textContent = Math.round(R.correct / 5 / mins) + " wpm";
}

function replayTotal() {
  const last = S.events.length ? S.events[S.events.length - 1].t : 1;
  return Math.max(last, 500);
}

function replayLoop() {
  if (!R.playing) return;
  const now = performance.now();
  const dt = (now - R.lastFrame) * R.speed;
  R.lastFrame = now;
  R.elapsed += dt;
  while (R.ptr < S.events.length && S.events[R.ptr].t <= R.elapsed) {
    replayApply(S.events[R.ptr]);
    R.ptr++;
  }
  updateReplayHud();
  if (R.elapsed >= replayTotal()) {
    R.playing = false;
    el.rpPlay.textContent = "▶";
    clearInterval(R.timer);
    return;
  }
}

el.rpPlay.addEventListener("click", () => {
  if (!R.active) return;
  if (R.playing) {
    R.playing = false;
    el.rpPlay.textContent = "▶";
    clearInterval(R.timer);
  } else {
    if (R.elapsed >= replayTotal()) replaySeek(0);
    R.playing = true;
    el.rpPlay.textContent = "⏸";
    R.lastFrame = performance.now();
    clearInterval(R.timer);
    R.timer = setInterval(replayLoop, 16);
  }
});

el.rpSpeed.addEventListener("click", () => {
  R.speed = R.speed === 1 ? 2 : R.speed === 2 ? 0.5 : 1;
  el.rpSpeed.textContent = R.speed + "x";
});

el.rpTrack.addEventListener("click", (e) => {
  if (!R.active) return;
  const rect = el.rpTrack.getBoundingClientRect();
  const frac = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
  replaySeek(frac * replayTotal());
});

/* ---------- restart / mode plumbing ---------- */
function stopTimers() {
  clearInterval(S.timer);
  S.timer = null;
  R.playing = false;
  clearInterval(R.timer);
}

function restart(sameWords) {
  stopTimers();
  Object.assign(S, {
    started: false, finished: false, startTime: 0,
    wi: 0, keystrokes: 0, correctKeystrokes: 0, correctInText: 0, typedChars: 0,
    keys: {}, samples: [], errsThisSec: 0, lastSec: 0, events: [],
    boundaryOk: [], paused: false, pauseAt: 0
  });

  if (sameWords && S.lastConfig) {
    S.words = S.lastConfig.slice();
  } else {
    if (S.mode === "time") S.words = genWords(70); // endless keeps topping up via ensureMore
    else if (S.mode === "words") S.words = genWords(isEndless() ? 50 : S.limit);
    else if (S.mode === "practice") S.words = genPractice();
    else if (S.mode === "daily") S.words = genDaily();
  }
  S.lastConfig = S.words.slice();
  S.input = S.words.map(() => "");

  el.resultsView.hidden = true;
  el.testView.hidden = false;
  el.caret.style.opacity = "";
  el.caret.classList.add("idle");
  el.weakstrip.innerHTML = "";
  el.liveWpm.textContent = "0";
  el.liveAcc.textContent = "100%";
  el.livePb.textContent = getPb() || "—";
  const timeMode = S.mode === "time";
  if (timeMode && isEndless()) {
    el.liveTime.textContent = "0.0"; // counts up, user ends manually
  } else if (timeMode) {
    el.liveTime.textContent = S.limit;
  } else {
    el.liveTime.textContent = "0";
  }
  el.timeLabel.textContent = timeMode ? "time" : "timer";
  el.statLeft.hidden = timeMode; // 'left' only makes sense in words mode
  if (!timeMode) el.liveLeft.textContent = isEndless() ? "∞" : S.words.length;
  el.endBtn.hidden = true; // appears when an endless test starts
  el.dailyResult.hidden = true;
  // mode note: daily shows today's streak/goal
  if (S.mode === "daily") {
    const st = getDailyState();
    el.modeNote.innerHTML = `today's words · streak <b>${st.streak}</b> · best <b>${st.best}</b>`;
  } else {
    el.modeNote.textContent = "";
  }
  el.livegraph.hidden = true; // reveals itself once the first samples land

  el.input.value = "";
  lastVal = "";
  renderAll();
  if (window.matchMedia("(pointer: fine)").matches) el.input.focus();
}

function buildSubbar() {
  el.subbar.innerHTML = "";
  if (!LIMITS[S.mode]) return; // practice / daily have no limit row
  for (const v of LIMITS[S.mode]) {
    const b = document.createElement("button");
    b.className = "limit" + (v === S.limit ? " active" : "");
    b.textContent = v;
    b.addEventListener("click", () => {
      S.limit = v;
      buildSubbar();
      restart();
    });
    el.subbar.appendChild(b);
  }
}

function setMode(mode) {
  S.mode = mode;
  for (const b of el.modes.children) b.classList.toggle("active", b.dataset.mode === mode);
  // daily & practice must be identical for everyone, so the toggles are locked there too
  const dim = mode === "practice" || mode === "daily";
  for (const t of [el.optPunct, el.optNums, el.optCaps]) {
    t.style.opacity = dim ? "0.35" : "";
    t.style.pointerEvents = dim ? "none" : "";
  }

  if (LIMITS[mode] && !LIMITS[mode].includes(S.limit)) S.limit = LIMITS[mode][1];
  buildSubbar();
  restart();
}

/* ---------- events ---------- */
for (const b of el.modes.children) {
  b.addEventListener("click", () => setMode(b.dataset.mode));
}

el.optPunct.addEventListener("click", togglePunct);
el.optNums.addEventListener("click", toggleNums);
el.optCaps.addEventListener("click", toggleCaps);
el.optSound.addEventListener("click", () => setSound(!soundOn));
el.optLofi.addEventListener("click", () => (lofiWanted ? stopLofi() : startLofi()));
el.lofiClose.addEventListener("mousedown", (e) => e.preventDefault()); // closing shouldn't blur/pause the test
el.lofiClose.addEventListener("click", stopLofi);
el.lofiMin.addEventListener("mousedown", (e) => e.preventDefault()); // same: minimize keeps the test focused
el.lofiMin.addEventListener("click", () => {
  if (!lofiWanted) return;
  lofiMinimized = !lofiMinimized;
  save("typeflow_lofi_min", lofiMinimized); // next open (even after a reload) uses this state
  renderLofiState(); // only collapses the video — the stream keeps playing
});

el.nextBtn.addEventListener("click", () => restart());
el.repeatBtn.addEventListener("click", () => restart(true));
el.practiceBtn.addEventListener("click", () => setMode("practice"));

/* endless mode: end the run manually */
el.endBtn.addEventListener("mousedown", (e) => e.preventDefault()); // keep typing input focused — no pause glitch
el.endBtn.addEventListener("click", () => {
  if (S.started && isEndless() && !S.finished) { resumeTest(); finish(); }
});

/* ---------- command palette ---------- */
function modeLabel() {
  if (isEndless()) return `endless ${S.mode}`;
  if (S.mode === "time" || S.mode === "words") return `${S.mode} ${S.limit}`;
  return S.mode; // practice / daily
}

function togglePunct() { S.punct = !S.punct; el.optPunct.classList.toggle("active", S.punct); restart(); }
function toggleNums() { S.nums = !S.nums; el.optNums.classList.toggle("active", S.nums); restart(); }
function toggleCaps() { S.caps = !S.caps; el.optCaps.classList.toggle("active", S.caps); restart(); }
function toggleTheme() {
  const on = !document.body.classList.contains("light");
  document.body.classList.toggle("light", on);
  el.optTheme.checked = on;
  save("typeflow_theme", on);
}

function setAccent(accent) {
  if (!["blue", "mint", "violet", "orange", "rose", "black"].includes(accent)) accent = "blue";
  document.body.dataset.accent = accent;
  save("typeflow_accent", accent);
  for (const b of $("#accent-options").children) {
    b.classList.toggle("active", b.dataset.accent === accent);
  }
  requestAnimationFrame(() => {
    if (S.samples.length >= 2) drawLive();
    if (!el.resultsView.hidden) drawResults();
    if (!el.statsView.hidden) renderStats();
  });
}

function setTypeSize(size) {
  if (!["compact", "standard", "large"].includes(size)) size = "standard";
  document.body.classList.remove("type-compact", "type-large");
  if (size !== "standard") document.body.classList.add("type-" + size);
  save("typeflow_type_size", size);
  for (const b of $("#type-sizes").children) {
    b.classList.toggle("active", b.dataset.size === size);
  }
  requestAnimationFrame(() => {
    S.LH = S.wordEls[0] ? S.wordEls[0].getBoundingClientRect().height : S.LH;
    updateScroll();
    setCaret();
  });
}

function setZen(on) {
  document.body.classList.toggle("zen", on);
  el.optZen.checked = on;
  save("typeflow_zen", on);
  el.settingsPop.hidden = true;
  requestAnimationFrame(setCaret);
}

const CMD_LIMITS = () => (LIMITS[S.mode] || []).map((v) => ({
  label: `${S.mode}: ${v}`,
  hint: v === ENDLESS ? "forever" : S.mode === "time" ? "seconds" : "words",
  run: () => { S.limit = v; buildSubbar(); restart(); }
}));

const CMDS = () => [
  { label: "mode — time", hint: "15/30/60/120", run: () => setMode("time") },
  { label: "mode — words", hint: "10/25/50/100", run: () => setMode("words") },
  { label: "mode — daily challenge", hint: "same words for everyone", run: () => setMode("daily") },
  { label: "practice weak keys", hint: "drill your worst letters", run: () => setMode("practice") },
  { label: "restart test", hint: "tab + enter", run: () => restart() },
  { label: "open stats", hint: "progress & personal bests", run: openStats },
  { label: "toggle punctuation", hint: S.punct ? "on" : "off", run: togglePunct },
  { label: "toggle numbers", hint: S.nums ? "on" : "off", run: toggleNums },
  { label: "toggle capitalization", hint: S.caps ? "on" : "off", run: toggleCaps },
  { label: "toggle typing sounds", hint: soundOn ? "on" : "off", run: () => setSound(!soundOn) },
  { label: "cycle sound profile", hint: soundProfile, run: () => setProfile(SAMPLE_PROFILES[(SAMPLE_PROFILES.indexOf(soundProfile) + 1) % SAMPLE_PROFILES.length]) },
  { label: "toggle light mode", hint: document.body.classList.contains("light") ? "on" : "off", run: toggleTheme },
  ...CMD_LIMITS()
];

let cmdSel = 0;
let cmdFiltered = [];

function renderCmd() {
  const q = el.cmdInput.value.trim().toLowerCase();
  cmdFiltered = CMDS().filter((c) => !q || c.label.toLowerCase().includes(q) || (c.hint || "").toLowerCase().includes(q));
  if (cmdSel >= cmdFiltered.length) cmdSel = Math.max(0, cmdFiltered.length - 1);
  el.cmdList.innerHTML = "";
  if (!cmdFiltered.length) {
    el.cmdList.innerHTML = `<div class="cmd-empty">no commands match "${q}"</div>`;
    return;
  }
  cmdFiltered.forEach((c, i) => {
    const d = document.createElement("div");
    d.className = "cmd-item" + (i === cmdSel ? " sel" : "");
    d.innerHTML = `<span>${c.label}</span>${c.hint ? `<span class="cmd-hint">${c.hint}</span>` : ""}`;
    d.addEventListener("mouseenter", () => { cmdSel = i; renderCmd(); });
    d.addEventListener("click", () => { cmdSel = i; cmdRun(); });
    el.cmdList.appendChild(d);
  });
  const sel = el.cmdList.querySelector(".sel");
  if (sel) sel.scrollIntoView({ block: "nearest" });
}

function cmdMove(d) { cmdSel = Math.max(0, Math.min(cmdFiltered.length - 1, cmdSel + d)); renderCmd(); }

function cmdRun() {
  const c = cmdFiltered[cmdSel];
  closeCmd();
  if (c) c.run();
}

function openCmd() {
  cmdSel = 0;
  el.cmdInput.value = "";
  el.cmdOverlay.hidden = false;
  renderCmd();
  el.cmdInput.focus();
}
function closeCmd() {
  el.cmdOverlay.hidden = true;
  if (!el.statsView.hidden) return; // stats owns focus while it's open
  if (window.matchMedia("(pointer: fine)").matches) el.input.focus();
}

el.cmdInput.addEventListener("input", () => { cmdSel = 0; renderCmd(); });
el.cmdOverlay.addEventListener("mousedown", (e) => { if (e.target === el.cmdOverlay) closeCmd(); });

/* ---------- stats view ---------- */
function fmtDur(sec) {
  if (sec < 3600) return Math.round(sec / 60) + "m";
  return (sec / 3600).toFixed(1) + "h";
}

function allPbs() {
  const out = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith(PB_PREFIX)) continue;
      const v = load(k, 0);
      if (!v) continue;
      const rest = k.slice(PB_PREFIX.length);
      // flags are a trailing run of p(unctuation), n(umbers), c(aps) — any combo
      const m = rest.match(/^(.*?)([pnc]*)$/);
      const body = m[1];
      const flagStr = m[2].split("").map((f) => ({ p: ".", n: "#", c: "Aa" })[f]).join(" ");
      const parts = body.split("_");
      out.push({ mode: parts[0], limit: parts[1] || "", flags: flagStr, wpm: v });
    }
  } catch { /* ignore */ }
  return out.sort((a, b) => b.wpm - a.wpm);
}

function drawHistGraph(hist) {
  const { ctx, w, h } = fitCanvas(el.histGraph);
  const pts = hist.slice(-60);
  el.histGraph.style.display = pts.length >= 2 ? "" : "none";
  if (pts.length < 2) return;
  const maxV = Math.max(60, ...pts.map((p) => p.wpm)) * 1.15;
  const pad = 14;
  const step = w / Math.max(pts.length - 1, 1);
  const yOf = (v) => h - pad - (v / maxV) * (h - pad * 2);

  ctx.strokeStyle = "rgba(255,255,255,0.04)";
  for (let i = 1; i <= 3; i++) {
    const y = (h / 4) * i;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }

  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, themeAccentRgba(0.18));
  grad.addColorStop(1, themeAccentRgba(0));
  drawSeries(ctx, pts.map((p) => p.wpm), w, h, maxV, pad);
  ctx.lineTo((pts.length - 1) * step, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // accuracy trend (own 0-100 axis, dashed)
  drawSeries(ctx, pts.map((p) => (p.acc / 100) * maxV), w, h, maxV, pad);
  ctx.strokeStyle = "rgba(34,197,94,0.45)";
  ctx.lineWidth = 2;
  ctx.setLineDash([4, 4]);
  ctx.stroke();
  ctx.setLineDash([]);

  drawSeries(ctx, pts.map((p) => p.wpm), w, h, maxV, pad);
  ctx.strokeStyle = themeAccent();
  ctx.lineWidth = 2.5;
  ctx.stroke();

  ctx.fillStyle = themeAccent();
  pts.forEach((p, i) => {
    ctx.beginPath();
    ctx.arc(i * step, yOf(p.wpm), 2.5, 0, Math.PI * 2);
    ctx.fill();
  });
}

function renderStats() {
  const hist = load(HIST_KEY, []);
  const last10 = hist.slice(-10);
  const avg = last10.length ? Math.round(last10.reduce((a, b) => a + b.wpm, 0) / last10.length) : 0;
  const best = hist.reduce((m, r) => Math.max(m, r.wpm), 0);
  const totalSec = hist.reduce((a, b) => a + (b.sec || 0), 0);
  const daily = getDailyState();

  const cards = [
    ["tests", hist.length],
    ["avg wpm (last 10)", avg || "—"],
    ["best wpm", best || "—"],
    ["time typed", hist.length ? fmtDur(totalSec) : "—"],
    ["daily streak", daily.streak || 0]
  ];
  el.statsTotals.innerHTML = cards
    .map(([label, v]) => `<div class="totalcard"><span>${v}</span><label>${label}</label></div>`)
    .join("");

  drawHistGraph(hist);

  const pbs = allPbs();
  if (!pbs.length) {
    el.pbTable.innerHTML = `<tr><td colspan="2" class="empty">no personal bests yet — finish a test to set one</td></tr>`;
  } else {
    el.pbTable.innerHTML =
      `<tr><th>mode</th><th>wpm</th></tr>` +
      pbs.map((p) => {
        const mode = p.mode + (p.limit ? " " + p.limit : "") + (p.flags ? " " + p.flags : "");
        return `<tr><td class="pb-mode">${mode}</td><td class="pb-wpm">${p.wpm}</td></tr>`;
      }).join("");
  }
}

function openStats() {
  el.statsView.hidden = false; // unhide first — a hidden canvas measures 0 wide
  renderStats();
  el.input.blur();
}
function closeStats() {
  el.statsView.hidden = true;
  if (window.matchMedia("(pointer: fine)").matches) el.input.focus();
}

el.btnStats.addEventListener("click", openStats);
el.statsClose.addEventListener("click", closeStats);

/* settings popover (light mode) */
el.btnSettings.addEventListener("click", (e) => {
  e.stopPropagation();
  unlockSoundPreviews();
  el.settingsPop.hidden = !el.settingsPop.hidden;
});
el.optTheme.addEventListener("change", toggleTheme);
el.optZen.addEventListener("change", () => setZen(el.optZen.checked));
el.zenExit.addEventListener("click", () => setZen(false));
el.soundVolume.addEventListener("input", () => {
  setVolume(Number(el.soundVolume.value) / 100);
  if (!soundOn && Number(el.soundVolume.value) > 0) setSound(true);
});
$("#accent-options").addEventListener("click", (e) => {
  const b = e.target.closest(".segbtn");
  if (b) setAccent(b.dataset.accent);
});
$("#type-sizes").addEventListener("click", (e) => {
  const b = e.target.closest(".segbtn");
  if (b) setTypeSize(b.dataset.size);
});
$("#sound-profiles").addEventListener("click", (e) => {
  const b = e.target.closest(".segbtn");
  if (!b) return;
  setProfile(b.dataset.p);
  setSound(b.dataset.p !== "off");
  previewProfile(b.dataset.p);
});
for (const button of $("#sound-profiles").querySelectorAll(".segbtn")) {
  button.addEventListener("mouseenter", () => previewProfile(button.dataset.p));
}
document.addEventListener("click", (e) => {
  if (el.settingsPop.hidden) return;
  if (!el.settingsPop.contains(e.target) && e.target !== el.btnSettings) el.settingsPop.hidden = true;
});
el.clearHistory.addEventListener("click", () => {
  if (!confirm("Clear all history and personal bests? This cannot be undone.")) return;
  try {
    const doomed = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(PB_PREFIX) || k === HIST_KEY || k === DAILY_KEY)) doomed.push(k);
    }
    doomed.forEach((k) => localStorage.removeItem(k));
  } catch { /* ignore */ }
  renderStats();
});

/* ---------- share ---------- */
function shareText() {
  const r = window.__lastResult;
  if (!r) return "";
  if (S.mode === "daily") {
    const st = getDailyState();
    return `typeflow daily ${todayKey()} — ${r.wpm} wpm, ${r.acc}% acc, ${r.cons}% cons 🔥${st.streak} day streak`;
  }
  return `typeflow ${modeLabel()} — ${r.wpm} wpm, ${r.acc}% acc, ${r.cons}% consistency`;
}

el.shareBtn.addEventListener("click", async () => {
  const txt = shareText();
  if (!txt) return;
  const done = () => {
    el.shareBtn.textContent = "copied!";
    setTimeout(() => { el.shareBtn.textContent = "copy result"; }, 1600);
  };
  try { await navigator.clipboard.writeText(txt); done(); }
  catch {
    const ta = document.createElement("textarea");
    ta.value = txt;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); done(); } catch { /* ignore */ }
    ta.remove();
  }
});

el.logo.addEventListener("click", () => { if (!el.statsView.hidden) closeStats(); });

/* focus handling — losing focus mid-test pauses the clock */
function showFocus(text) {
  if (S.finished) return;
  if (text) el.focusnote.textContent = text;
  el.focusnote.hidden = false;
  el.typewrap.classList.add("unfocused");
}
function hideFocus() {
  el.focusnote.hidden = true;
  el.typewrap.classList.remove("unfocused");
}

function pauseTest() {
  if (!S.started || S.finished || S.paused) return;
  S.paused = true;
  S.pauseAt = performance.now();
  showFocus("paused — click to resume");
}
function resumeTest() {
  if (!S.paused) return;
  S.paused = false;
  S.startTime += performance.now() - S.pauseAt; // shift the clock past the gap
  hideFocus();
  setCaret();
}

el.typewrap.addEventListener("mousedown", (e) => {
  e.preventDefault();
  el.input.focus();
});
el.focusnote.addEventListener("click", () => el.input.focus());
el.input.addEventListener("focus", () => { hideFocus(); resumeTest(); });
el.input.addEventListener("blur", () => {
  if (S.finished || !el.cmdOverlay.hidden || !el.statsView.hidden || !el.settingsPop.hidden) return;
  if (S.started) pauseTest();
  else showFocus("click here to start typing");
});

/* desktop keyboard */
let tabDown = false;
document.addEventListener("keydown", (e) => {
  // command palette swallows everything while it's open
  if (!el.cmdOverlay.hidden) {
    if (e.key === "Escape") { e.preventDefault(); closeCmd(); return; }
    if (e.key === "ArrowDown") { e.preventDefault(); cmdMove(1); return; }
    if (e.key === "ArrowUp") { e.preventDefault(); cmdMove(-1); return; }
    if (e.key === "Enter") { e.preventDefault(); cmdRun(); return; }
    if (e.key === "Tab") { e.preventDefault(); return; }
    return; // let normal typing reach the filter field
  }

  if ((e.key === "k" || e.key === "K") && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    openCmd();
    return;
  }

  if (e.ctrlKey || e.metaKey || e.altKey) return;

  // settings popover: Escape closes it
  if (!el.settingsPop.hidden && e.key === "Escape") { el.settingsPop.hidden = true; return; }

  // stats view owns the keyboard while open
  if (!el.statsView.hidden) {
    if (e.key === "Escape") closeStats();
    return;
  }
  if (e.key === "Tab") { e.preventDefault(); tabDown = true; return; }
  const resultsOpen = !el.resultsView.hidden;

  if (e.key === "Enter") {
    if (resultsOpen) {
      // let a focused button handle its own Enter
      const ae = document.activeElement;
      if (!(ae && ae.tagName === "BUTTON" && el.resultsView.contains(ae))) {
        e.preventDefault();
        restart();
      }
      return;
    }
    e.preventDefault(); // never insert a newline
    if (tabDown) { tabDown = false; restart(); }
    return;
  }
  if (e.key === "Escape") {
    // in endless mode Esc ends the run instead of discarding it
    if (isEndless() && S.started && !S.finished) finish();
    else restart();
    return;
  }
  if (resultsOpen) return;
  if (e.key === "Backspace") { e.preventDefault(); handleBackspace(); return; }
  if (e.key.length === 1) { e.preventDefault(); handleChar(e.key); }
});
document.addEventListener("keyup", (e) => {
  if (e.key === "Tab") tabDown = false;
});

/* mobile input: diff-based */
let lastVal = "";
el.input.addEventListener("input", () => {
  const v = el.input.value;
  if (v.length > lastVal.length) {
    for (let i = lastVal.length; i < v.length; i++) handleChar(v[i]);
  } else if (v.length < lastVal.length) {
    for (let i = 0; i < lastVal.length - v.length; i++) handleBackspace();
  }
  lastVal = v;
});
el.input.addEventListener("focus", () => { lastVal = el.input.value; });

/* resize */
window.addEventListener("resize", () => {
  if (el.testView.hidden) return;
  S.LH = S.wordEls[0] ? S.wordEls[0].getBoundingClientRect().height : S.LH;
  updateScroll();
  setCaret();
  if (S.samples.length >= 2) drawLive();
});

/* ---------- init ---------- */
(function init() {
  const st = load("typeflow_settings", null);
  if (st) {
    S.mode = st.mode || "time";
    S.limit = st.limit || 30;
    S.punct = !!st.punct;
    S.nums = !!st.nums;
    S.caps = !!st.caps;
    // modes that no longer exist (quote/custom) fall back to time
    const valid = ["time", "words", "daily"];
    if (!valid.includes(S.mode)) S.mode = "time";
  }
  // theme
  const light = load("typeflow_theme", false);
  document.body.classList.toggle("light", !!light);
  el.optTheme.checked = !!light;
  setAccent(load("typeflow_accent", "blue"));
  setTypeSize(load("typeflow_type_size", "standard"));
  setZen(load("typeflow_zen", false));
  setVolume(soundVolume);

  el.optPunct.classList.toggle("active", S.punct);
  el.optNums.classList.toggle("active", S.nums);
  el.optCaps.classList.toggle("active", S.caps);
  el.optSound.classList.toggle("active", soundOn);
  setProfile(soundProfile);
  for (const b of el.modes.children) b.classList.toggle("active", b.dataset.mode === S.mode);
  if (LIMITS[S.mode] && !LIMITS[S.mode].includes(S.limit)) S.limit = LIMITS[S.mode][1];
  buildSubbar();
  restart();

  window.addEventListener("beforeunload", () => {
    save("typeflow_settings", { mode: S.mode, limit: S.limit, punct: S.punct, nums: S.nums, caps: S.caps });
  });
})();
